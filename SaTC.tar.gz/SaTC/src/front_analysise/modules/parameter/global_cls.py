#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/4 上午12:15
# @Author  : TT
# @File    : global_cls.py


class Count():
    FUNCTION_COUNT = 0
    KEYWORDS_COUNT = 0
    BASE_FILTER_PARA = 0
    BASE_FILTER_API = 0