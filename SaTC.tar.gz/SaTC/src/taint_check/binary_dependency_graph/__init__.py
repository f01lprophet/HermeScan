from taint_check.binary_dependency_graph import *
